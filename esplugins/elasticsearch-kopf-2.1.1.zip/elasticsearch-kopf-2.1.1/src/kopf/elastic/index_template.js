function IndexTemplate(name, body) {
  this.name = name;
  this.body = body;
}
